# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['pyvid']

package_data = \
{'': ['*']}

install_requires = \
['click-spinner>=0.1.8,<0.2.0',
 'click>=7.0,<8.0',
 'ffmpeg-python>=0.1.16,<0.2.0',
 'hurry.filesize>=0.9.0,<0.10.0']

entry_points = \
{'console_scripts': ['pyvid = pyvid:main']}

setup_kwargs = {
    'name': 'pyvid',
    'version': '0.0.3',
    'description': 'Video conversion utility',
    'long_description': '# pyvid\n',
    'author': 'jdxt',
    'author_email': 'jytrn@protonmail.com',
    'url': 'https://github.com/0jdxt/pyvid',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
}


setup(**setup_kwargs)

# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['pyvid']

package_data = \
{'': ['*']}

install_requires = \
['click-spinner>=0.1.8,<0.2.0',
 'click>=7.0,<8.0',
 'ffmpeg-python>=0.1.16,<0.2.0',
 'hurry.filesize>=0.9.0,<0.10.0',
 'pytoml>=0.1.19,<0.2.0']

entry_points = \
{'console_scripts': ['pyvid = pyvid:main']}

setup_kwargs = {
    'name': 'pyvid',
    'version': '0.0.6',
    'description': 'Video conversion utility using ffmpeg',
    'long_description': '# pyvid 0.0.6-alpha\n\n[![Documentation Status](https://readthedocs.org/projects/pyvid/badge/?version=latest)](https://pyvid.readthedocs.io/en/latest/?badge=latest)\n\n\n## Dependencies\n- [install](https://www.ffmpeg.org/download.html)\n  ffmpeg and make sure the executable is in PATH\n- only works on windows atm\n\n## Installation\n\nInstall as global executable\n```cmd\n>pip install pyvid\n```\n\n## Usage\n\nThe following\n```cmd\n>pyvid files -e avi\n```\nwill convert all `.avi` files in directory `files/` to output directory `converted/files/`\n\nUses defaults on ffmpeg executable to get high quality and low file size.\n\n```\nUsage: pyvid [OPTIONS] FOLDER\n\nOptions:\n  -e, --ext TEXT  File extension to look for\n  -y, --force     Disable convert prompt\n  -d, --rem       Delete source video file(s)\n  --version       Show the version and exit.\n  --help          Show this message and exit.\n```\n',
    'author': 'jdxt',
    'author_email': 'jytrn@protonmail.com',
    'url': 'https://github.com/0jdxt/pyvid',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
}


setup(**setup_kwargs)

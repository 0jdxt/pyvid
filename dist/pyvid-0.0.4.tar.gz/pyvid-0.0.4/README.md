# pyvid 0.0.4

## Usage
```
Usage: pyvid [OPTIONS] FOLDER

Options:
  -e, --ext TEXT  File extension to look for
  -y, --force     Disable convert prompt
  -d, --rem       Delete source video file(s)
  --version       Show the version and exit.
  --help          Show this message and exit.
```
